# Deborah Perez | Multi-Paradigm Programming Project

This repository contains an interactive final project for a Programming Languages course. The website includes seven browser-based programs that explore imperative, functional, logical, object-oriented, and free-choice programming approaches.

## Programs Included

1. **UPRM GPA Calculator** — Imperative, Python with PyScript
2. **Study Session Timer** — Functional, Elm
3. **Career Path Advisor** — Logical, Prolog with Tau Prolog
4. **Mini Smart Academic Task Planner** — Object-Oriented, TypeScript
5. **Flashcard Generator** — JavaScript
6. **Internship Application Tracker** — JavaScript with localStorage
7. **Dynamic Résumé / CV Generator** — JavaScript + JSON with PDF download

## How to Run

1. Open the project folder in Visual Studio Code.
2. Open `index.html` with the Live Server extension.
3. Keep an internet connection active because PyScript, Tau Prolog, Google Fonts, and jsPDF are loaded through CDNs.

## Modular Project Structure

```text
multi_paradigm_programming_project/
├── index.html                    # Main website
├── README.md                     # Project documentation
├── cv                            # Required root JSON file used by the CV class
├── elm.json                      # Elm project configuration
│
├── assets/
│   ├── css/
│   │   └── styles.css            # Complete visual theme
│   └── js/
│       ├── cv.js                 # Dynamic CV class and PDF generation
│       ├── flashcards.js         # Flashcard program
│       ├── gpa-fallback.js       # Browser support for GPA interface
│       ├── internship-tracker.js # Internship tracker
│       └── prolog-career.js      # Tau Prolog integration
│
├── data/
│   └── cv.json                   # Readable backup copy of CV data
│
├── src/                          # Original source code by language
│   ├── elm/
│   │   └── StudySessionTimer.elm
│   ├── python/
│   │   └── gpa_calculator.py
│   └── typescript/
│       └── task-planner.ts
│
└── dist/                         # Browser-ready compiled/output files
    ├── elm/
    │   └── study-session-timer.js
    └── typescript/
        └── task-planner.js
```

## CV Requirements

The CV program:

- reads its data from the root file named `cv`;
- contains at least ten CV categories;
- generates the résumé dynamically in HTML;
- lets the user activate or deactivate individual entries;
- generates and downloads a PDF using jsPDF.

## Technologies

- HTML and CSS
- Python / PyScript
- Elm
- Prolog / Tau Prolog
- TypeScript
- JavaScript
- JSON
- jsPDF

## Credits and References

- PyScript: https://pyscript.net/
- Elm: https://elm-lang.org/
- Tau Prolog: http://tau-prolog.org/
- jsPDF: https://github.com/parallax/jsPDF
