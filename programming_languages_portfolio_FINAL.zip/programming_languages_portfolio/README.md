# Deborah Perez | Programming Languages Portfolio

This repository contains a personal web portfolio developed for a Programming Languages final project. The site includes seven browser-based programs that explore imperative, functional, logical, object-oriented, and free-choice programming approaches.

## Programs Included

1. **UPRM GPA Calculator with dynamic course rows**  
   - Paradigm: Imperative  
   - Language: Python with PyScript

2. **Study Session Timer**  
   - Paradigm: Functional  
   - Language: Elm  
   - Uses the Elm Model-View-Update architecture and timed subscriptions  
   - Source file: `elm/StudySessionTimer.elm`

3. **Career Path Advisor**  
   - Paradigm: Logical  
   - Language: Prolog using Tau Prolog

4. **Mini Smart Academic Task Planner**  
   - Paradigm: Object-Oriented  
   - Language: TypeScript  
   - Source file: `ts/task-planner.ts`

5. **Flashcard Generator**  
   - Free-choice program  
   - Language: JavaScript

6. **Internship Application Tracker**  
   - Free-choice program  
   - Language: JavaScript

7. **Dynamic Résumé / CV Generator**  
   - Language: JavaScript + JSON  
   - Reads data from a root file named `cv`  
   - Prints résumé in HTML  
   - Allows entries to be activated/deactivated  
   - Includes a PDF download button

## How to Run

Open the project folder in Visual Studio Code and run `index.html` using the Live Server extension.

Some external browser libraries are loaded through CDN:
- PyScript
- Tau Prolog
- jsPDF

## Project Structure

```text
programming_languages_portfolio/
├── index.html
├── styles.css
├── cv
├── cv.json
├── README.md
├── js/
├── python/
├── elm/
└── ts/
```

## Credits and References

- PyScript: https://pyscript.net/
- Elm language: https://elm-lang.org/
- Tau Prolog: http://tau-prolog.org/
- jsPDF: https://github.com/eKoopmans/jsPDF


## Version 4 Updates

- The GPA calculator now allows users to add or remove as many courses as needed.
- The résumé PDF download was updated to use a PDF-safe copy of the résumé so the downloaded file does not appear blank.


## Version 7 Update

- Replaced the Elm Study Session Timer with an Elm Study Session Timer.
- The timer includes adjustable study and break durations, Start, Pause, Reset, mode switching, and a completed-session counter.
